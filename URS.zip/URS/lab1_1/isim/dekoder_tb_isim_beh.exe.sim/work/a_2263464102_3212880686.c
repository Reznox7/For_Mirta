/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "G:/_Faks/URS/lab1_1/zad1.vhd";
extern char *IEEE_P_2592010699;

char *ieee_p_2592010699_sub_1837678034_503743352(char *, char *, char *, char *);


static void work_a_2263464102_3212880686_p_0(char *t0)
{
    char t3[16];
    char t5[16];
    char t16[16];
    char t19[16];
    char *t1;
    char *t2;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned char t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t17;
    char *t20;
    char *t21;
    int t22;
    unsigned int t23;
    char *t24;
    unsigned int t25;
    unsigned char t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;

LAB0:    xsi_set_current_line(16, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4231);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 2;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (2 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t3, t1, t5);
    t10 = (t3 + 12U);
    t9 = *((unsigned int *)t10);
    t11 = (1U * t9);
    t12 = 1;
    if (3U == t11)
        goto LAB5;

LAB6:    t12 = 0;

LAB7:    if (t12 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4242);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 2;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (2 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t3, t1, t5);
    t10 = (t3 + 12U);
    t9 = *((unsigned int *)t10);
    t11 = (1U * t9);
    t12 = 1;
    if (3U == t11)
        goto LAB15;

LAB16:    t12 = 0;

LAB17:    if (t12 != 0)
        goto LAB13;

LAB14:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4253);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 2;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (2 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t3, t1, t5);
    t10 = (t3 + 12U);
    t9 = *((unsigned int *)t10);
    t11 = (1U * t9);
    t12 = 1;
    if (3U == t11)
        goto LAB25;

LAB26:    t12 = 0;

LAB27:    if (t12 != 0)
        goto LAB23;

LAB24:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4264);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 2;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (2 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t3, t1, t5);
    t10 = (t3 + 12U);
    t9 = *((unsigned int *)t10);
    t11 = (1U * t9);
    t12 = 1;
    if (3U == t11)
        goto LAB35;

LAB36:    t12 = 0;

LAB37:    if (t12 != 0)
        goto LAB33;

LAB34:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4275);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 2;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (2 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t3, t1, t5);
    t10 = (t3 + 12U);
    t9 = *((unsigned int *)t10);
    t11 = (1U * t9);
    t12 = 1;
    if (3U == t11)
        goto LAB45;

LAB46:    t12 = 0;

LAB47:    if (t12 != 0)
        goto LAB43;

LAB44:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4286);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 2;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (2 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t3, t1, t5);
    t10 = (t3 + 12U);
    t9 = *((unsigned int *)t10);
    t11 = (1U * t9);
    t12 = 1;
    if (3U == t11)
        goto LAB55;

LAB56:    t12 = 0;

LAB57:    if (t12 != 0)
        goto LAB53;

LAB54:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4297);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 2;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (2 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t3, t1, t5);
    t10 = (t3 + 12U);
    t9 = *((unsigned int *)t10);
    t11 = (1U * t9);
    t12 = 1;
    if (3U == t11)
        goto LAB65;

LAB66:    t12 = 0;

LAB67:    if (t12 != 0)
        goto LAB63;

LAB64:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4308);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 2;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (2 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t3, t1, t5);
    t10 = (t3 + 12U);
    t9 = *((unsigned int *)t10);
    t11 = (1U * t9);
    t12 = 1;
    if (3U == t11)
        goto LAB75;

LAB76:    t12 = 0;

LAB77:    if (t12 != 0)
        goto LAB73;

LAB74:
LAB3:    t1 = (t0 + 2672);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(17, ng0);
    t17 = (t0 + 4234);
    t20 = (t19 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = 0;
    t21 = (t20 + 4U);
    *((int *)t21) = 7;
    t21 = (t20 + 8U);
    *((int *)t21) = 1;
    t22 = (7 - 0);
    t23 = (t22 * 1);
    t23 = (t23 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t23;
    t21 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t16, t17, t19);
    t24 = (t16 + 12U);
    t23 = *((unsigned int *)t24);
    t25 = (1U * t23);
    t26 = (8U != t25);
    if (t26 == 1)
        goto LAB11;

LAB12:    t27 = (t0 + 2752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t21, 8U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB3;

LAB5:    t13 = 0;

LAB8:    if (t13 < 3U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t14 = (t2 + t13);
    t15 = (t7 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB6;

LAB10:    t13 = (t13 + 1);
    goto LAB8;

LAB11:    xsi_size_not_matching(8U, t25, 0);
    goto LAB12;

LAB13:    xsi_set_current_line(19, ng0);
    t17 = (t0 + 4245);
    t20 = (t19 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = 0;
    t21 = (t20 + 4U);
    *((int *)t21) = 7;
    t21 = (t20 + 8U);
    *((int *)t21) = 1;
    t22 = (7 - 0);
    t23 = (t22 * 1);
    t23 = (t23 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t23;
    t21 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t16, t17, t19);
    t24 = (t16 + 12U);
    t23 = *((unsigned int *)t24);
    t25 = (1U * t23);
    t26 = (8U != t25);
    if (t26 == 1)
        goto LAB21;

LAB22:    t27 = (t0 + 2752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t21, 8U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB3;

LAB15:    t13 = 0;

LAB18:    if (t13 < 3U)
        goto LAB19;
    else
        goto LAB17;

LAB19:    t14 = (t2 + t13);
    t15 = (t7 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB16;

LAB20:    t13 = (t13 + 1);
    goto LAB18;

LAB21:    xsi_size_not_matching(8U, t25, 0);
    goto LAB22;

LAB23:    xsi_set_current_line(21, ng0);
    t17 = (t0 + 4256);
    t20 = (t19 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = 0;
    t21 = (t20 + 4U);
    *((int *)t21) = 7;
    t21 = (t20 + 8U);
    *((int *)t21) = 1;
    t22 = (7 - 0);
    t23 = (t22 * 1);
    t23 = (t23 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t23;
    t21 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t16, t17, t19);
    t24 = (t16 + 12U);
    t23 = *((unsigned int *)t24);
    t25 = (1U * t23);
    t26 = (8U != t25);
    if (t26 == 1)
        goto LAB31;

LAB32:    t27 = (t0 + 2752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t21, 8U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB3;

LAB25:    t13 = 0;

LAB28:    if (t13 < 3U)
        goto LAB29;
    else
        goto LAB27;

LAB29:    t14 = (t2 + t13);
    t15 = (t7 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB26;

LAB30:    t13 = (t13 + 1);
    goto LAB28;

LAB31:    xsi_size_not_matching(8U, t25, 0);
    goto LAB32;

LAB33:    xsi_set_current_line(23, ng0);
    t17 = (t0 + 4267);
    t20 = (t19 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = 0;
    t21 = (t20 + 4U);
    *((int *)t21) = 7;
    t21 = (t20 + 8U);
    *((int *)t21) = 1;
    t22 = (7 - 0);
    t23 = (t22 * 1);
    t23 = (t23 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t23;
    t21 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t16, t17, t19);
    t24 = (t16 + 12U);
    t23 = *((unsigned int *)t24);
    t25 = (1U * t23);
    t26 = (8U != t25);
    if (t26 == 1)
        goto LAB41;

LAB42:    t27 = (t0 + 2752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t21, 8U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB3;

LAB35:    t13 = 0;

LAB38:    if (t13 < 3U)
        goto LAB39;
    else
        goto LAB37;

LAB39:    t14 = (t2 + t13);
    t15 = (t7 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB36;

LAB40:    t13 = (t13 + 1);
    goto LAB38;

LAB41:    xsi_size_not_matching(8U, t25, 0);
    goto LAB42;

LAB43:    xsi_set_current_line(25, ng0);
    t17 = (t0 + 4278);
    t20 = (t19 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = 0;
    t21 = (t20 + 4U);
    *((int *)t21) = 7;
    t21 = (t20 + 8U);
    *((int *)t21) = 1;
    t22 = (7 - 0);
    t23 = (t22 * 1);
    t23 = (t23 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t23;
    t21 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t16, t17, t19);
    t24 = (t16 + 12U);
    t23 = *((unsigned int *)t24);
    t25 = (1U * t23);
    t26 = (8U != t25);
    if (t26 == 1)
        goto LAB51;

LAB52:    t27 = (t0 + 2752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t21, 8U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB3;

LAB45:    t13 = 0;

LAB48:    if (t13 < 3U)
        goto LAB49;
    else
        goto LAB47;

LAB49:    t14 = (t2 + t13);
    t15 = (t7 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB46;

LAB50:    t13 = (t13 + 1);
    goto LAB48;

LAB51:    xsi_size_not_matching(8U, t25, 0);
    goto LAB52;

LAB53:    xsi_set_current_line(27, ng0);
    t17 = (t0 + 4289);
    t20 = (t19 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = 0;
    t21 = (t20 + 4U);
    *((int *)t21) = 7;
    t21 = (t20 + 8U);
    *((int *)t21) = 1;
    t22 = (7 - 0);
    t23 = (t22 * 1);
    t23 = (t23 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t23;
    t21 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t16, t17, t19);
    t24 = (t16 + 12U);
    t23 = *((unsigned int *)t24);
    t25 = (1U * t23);
    t26 = (8U != t25);
    if (t26 == 1)
        goto LAB61;

LAB62:    t27 = (t0 + 2752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t21, 8U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB3;

LAB55:    t13 = 0;

LAB58:    if (t13 < 3U)
        goto LAB59;
    else
        goto LAB57;

LAB59:    t14 = (t2 + t13);
    t15 = (t7 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB56;

LAB60:    t13 = (t13 + 1);
    goto LAB58;

LAB61:    xsi_size_not_matching(8U, t25, 0);
    goto LAB62;

LAB63:    xsi_set_current_line(29, ng0);
    t17 = (t0 + 4300);
    t20 = (t19 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = 0;
    t21 = (t20 + 4U);
    *((int *)t21) = 7;
    t21 = (t20 + 8U);
    *((int *)t21) = 1;
    t22 = (7 - 0);
    t23 = (t22 * 1);
    t23 = (t23 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t23;
    t21 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t16, t17, t19);
    t24 = (t16 + 12U);
    t23 = *((unsigned int *)t24);
    t25 = (1U * t23);
    t26 = (8U != t25);
    if (t26 == 1)
        goto LAB71;

LAB72:    t27 = (t0 + 2752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t21, 8U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB3;

LAB65:    t13 = 0;

LAB68:    if (t13 < 3U)
        goto LAB69;
    else
        goto LAB67;

LAB69:    t14 = (t2 + t13);
    t15 = (t7 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB66;

LAB70:    t13 = (t13 + 1);
    goto LAB68;

LAB71:    xsi_size_not_matching(8U, t25, 0);
    goto LAB72;

LAB73:    xsi_set_current_line(31, ng0);
    t17 = (t0 + 4311);
    t20 = (t19 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = 0;
    t21 = (t20 + 4U);
    *((int *)t21) = 7;
    t21 = (t20 + 8U);
    *((int *)t21) = 1;
    t22 = (7 - 0);
    t23 = (t22 * 1);
    t23 = (t23 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t23;
    t21 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t16, t17, t19);
    t24 = (t16 + 12U);
    t23 = *((unsigned int *)t24);
    t25 = (1U * t23);
    t26 = (8U != t25);
    if (t26 == 1)
        goto LAB81;

LAB82:    t27 = (t0 + 2752);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t21, 8U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB3;

LAB75:    t13 = 0;

LAB78:    if (t13 < 3U)
        goto LAB79;
    else
        goto LAB77;

LAB79:    t14 = (t2 + t13);
    t15 = (t7 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB76;

LAB80:    t13 = (t13 + 1);
    goto LAB78;

LAB81:    xsi_size_not_matching(8U, t25, 0);
    goto LAB82;

}


extern void work_a_2263464102_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2263464102_3212880686_p_0};
	xsi_register_didat("work_a_2263464102_3212880686", "isim/dekoder_tb_isim_beh.exe.sim/work/a_2263464102_3212880686.didat");
	xsi_register_executes(pe);
}
