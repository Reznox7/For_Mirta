/*
 * zad1.c
 *
 * Created: 04-May-22 14:52:16
 * Author : Dominik
 */ 

// Provjera na labosu da li je frekv. takta mikrokontrolera jednaka 3.33Mhz
#define F_CPU 3333333

#include <avr/io.h>
#include <util/delay.h>
#include <stdbool.h>
#include <avr/interrupt.h>

// S1 TIPKA
// Da li je pin PA7 u ugasenom ili upaljenom stanju
#define PA7_LOW !(PORTA.IN & (1 << 7))
// Da li je pin PA7 uzrok prekida
#define PA7_INTERRUPT PORTA.INTFLAGS & (1 << 7)
// Ciscenje zastavice da je PA7 napravio interrupt
#define PA7_CLEAR_INTERRUPT_FLAG PORTA.INTFLAGS &= (1 << 7)

// Za sve ispod vrijedi isto kao za iznad

// S2 TIPKA
#define PA6_LOW !(PORTA.IN & (1 << 6))
#define PA6_INTERRUPT PORTA.INTFLAGS & (1 << 6)
#define PA6_CLEAR_INTERRUPT_FLAG PORTA.INTFLAGS &= (1 << 6)

// S3 TIPKA
#define PA5_LOW !(PORTA.IN & (1 << 5))
#define PA5_INTERRUPT PORTA.INTFLAGS & (1 << 5)
#define PA5_CLEAR_INTERRUPT_FLAG PORTA.INTFLAGS &= (1 << 5)

// S4 TIPKA
#define PA4_LOW !(PORTA.IN & (1 << 4))
#define PA4_INTERRUPT PORTA.INTFLAGS & (1 << 4)
#define PA4_CLEAR_INTERRUPT_FLAG PORTA.INTFLAGS &= (1 << 4)

volatile uint8_t S1_flag;
volatile uint8_t S2_flag;
volatile uint8_t S3_flag;
volatile uint8_t S4_flag;

// Interrupt Service Routine
ISR(PORTA_PORT_vect){
	if(PA7_INTERRUPT){
		S1_flag = 1;
		PA7_CLEAR_INTERRUPT_FLAG;
	}
	if (PA6_INTERRUPT){
		S2_flag = 1;
		PA6_CLEAR_INTERRUPT_FLAG;
	}
	if (PA5_INTERRUPT){
		S3_flag = 1;
		PA5_CLEAR_INTERRUPT_FLAG;
	}
	if (PA4_INTERRUPT){
		S4_flag = 1;
		PA4_CLEAR_INTERRUPT_FLAG;
	}
}

int main(void)
{
    /* Replace with your application code */
	// Sto koristimo na outputu
	PORTD.DIR |= 0b11110000;
	
	// Init zastavice za interruptove na 0
	S1_flag = 0;
	S2_flag = 0;
	S3_flag = 0;
	S4_flag = 0;
	
	// Interruptovi na rastucim bridovima
	PORTA.PIN7CTRL |= PORT_PULLUPEN_bm |  PORT_ISC_BOTHEDGES_gc;
	PORTA.PIN6CTRL |= PORT_PULLUPEN_bm |  PORT_ISC_BOTHEDGES_gc;
	PORTA.PIN5CTRL |= PORT_PULLUPEN_bm |  PORT_ISC_BOTHEDGES_gc;
	PORTA.PIN4CTRL |= PORT_PULLUPEN_bm |  PORT_ISC_BOTHEDGES_gc;
	
	// Dozvoli interruptove
	sei();
    while (1) 
    {
		if(S1_flag){
			
			// UPALI LEDICU
			PORTD.OUT |= (1 << 7);
			S1_flag = 0;
			
			/// Ako treba gasiti ostale
			PORTD.OUT &= ~(1 << 6); 
			PORTD.OUT &= ~(1 << 5); 
			PORTD.OUT &= ~(1 << 4); 
		}
		else if (S2_flag){
			PORTD.OUT |= (1 << 6);
			S2_flag = 0;
			PORTD.OUT &= ~(1 << 7);
			PORTD.OUT &= ~(1 << 5);
			PORTD.OUT &= ~(1 << 4);
		}
		else if (S3_flag) {
			PORTD.OUT |= (1 << 5);
			S3_flag = 0;
			PORTD.OUT &= ~(1 << 6);
			PORTD.OUT &= ~(1 << 7);
			PORTD.OUT &= ~(1 << 4);
		}
		else if (S4_flag) {
			PORTD.OUT |= (1 << 4);
			S4_flag = 0;
			PORTD.OUT &= ~(1 << 6);
			PORTD.OUT &= ~(1 << 5);
			PORTD.OUT &= ~(1 << 7);
		}
		_delay_ms(10);		
    }
}