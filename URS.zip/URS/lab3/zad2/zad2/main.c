/*
 * zad2.c
 * Author : Dominik
 */ 


// Frekvencija takta
#define F_CPU 3333333

#include <avr/io.h>
#include <stdio.h>
#include <util/delay.h>

// Brzina komunikacije (bps)
#define BAUD_RATE 115200
// Broj konverzija po 1 s
#define SAMPLES 100

// Retargeting funkcija
// Ispisuje na konzolu tj. serijski port
int usart_putchar(char c, FILE *stream) {
	while (!(USART3.STATUS & USART_DREIF_bm));
	USART3.TXDATAL = c;
	return 0;
}
// Instanciranje usart zapisivanja na konzolu preko STDOUT
static FILE port_out = FDEV_SETUP_STREAM(usart_putchar,
NULL, _FDEV_SETUP_WRITE);


int main(void)
{
    /* Replace with your application code */
	
	// Povezivanje STDOUT i mojeg port_STDOUT
	stdout = &port_out;
	
	// Koristimo int za sve jer u zadatku zadano da moraju cijeli brojevi biti
	uint16_t temp_result;
	uint32_t sum = 0;
	float result;
	
	float voltage = 0.0;
	
	// Definicija izlaza ==> Serijski port = AN POT
	PORTB.DIR |= 0b00000001;
	
	// Postavljanje BAUD-a (Formula sa preze) i USART konzole
	USART3.BAUD = ((uint32_t)F_CPU * 64) / (16 * (uint32_t) BAUD_RATE);
    USART3.CTRLB |= USART_TXEN_bm; // TX-only enable
	
	// Konfiguriranje pretvornika
	// Koristi unutra�nji napon kao referentni napon (VDD, 3.3)
	ADC0.CTRLC |= ADC_REFSEL_VDDREF_gc;
	ADC0.MUXPOS |= ADC_MUXPOS_AIN0_gc;
	
	// Single Conversion mode enable
	ADC0.CTRLA = 0b00000001;
	int counter = 0;
	while (1) 
    {
		// Pokreni ADC konverziju i cekaj dok zavrsi pa ukloni flag
		ADC0.COMMAND = 0b00000001; 
		while (!(ADC0.INTFLAGS & ADC_RESRDY_bm));
		ADC0.INTFLAGS = ADC_RESRDY_bm;
		
		// Trenutnu izracunamo i dodajmo u sumu 
		voltage = (float)ADC0.RES / 1023.f * 3.3f;
		temp_result = (uint16_t) (voltage * 1000);
		sum += temp_result;
		counter++;
		_delay_ms(10);
		
		// Dobili smo 100 vrijednosti, treba srednja
		if (counter == SAMPLES){
			counter = 0;
			result =  sum / SAMPLES;
			printf("Srednja vrijednost: %3d mV\r\n", (int)result);
			sum = 0;
		}
    }
}

