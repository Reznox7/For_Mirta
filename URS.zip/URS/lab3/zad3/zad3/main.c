/*
 * zad3.c
 *
 * Created: 04-May-22 10:47:07
 * Author : Dominik
 */ 
#define F_CPU 3333333
#include <avr/io.h>
#include <stdio.h>
#include <util/delay.h>

#define SEG_A (1 << 1)
#define SEG_B (1 << 0)
#define SEG_C (1 << 4)
#define SEG_D (1 << 7)
#define SEG_E (1 << 5)
#define SEG_F (1 << 2)
#define SEG_G (1 << 3)
#define SEG_DP (1 << 6)

#define SEL_DISP_1 (1 << 2)
#define SEL_DISP_2 (1 << 3)

int main(void)
{
	const unsigned char segment_codes[10] = {
		SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F,// 0
		SEG_B | SEG_C, // 1
		SEG_A | SEG_B | SEG_G | SEG_E | SEG_D, // 2
		SEG_A | SEG_B | SEG_C | SEG_D | SEG_G, // 3
		SEG_F | SEG_G | SEG_B | SEG_C, // 4
		SEG_A | SEG_F | SEG_G | SEG_C | SEG_D, // 5
		SEG_A | SEG_F | SEG_G | SEG_C | SEG_D | SEG_E,// 6
		SEG_A | SEG_B | SEG_C, // 7
		SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F | SEG_G, // 8
		SEG_A | SEG_B | SEG_C | SEG_D | SEG_F | SEG_G}; // 9
	uint8_t count; 
	PORTC.DIR = 0b11111111;
	PORTE.DIR = 0b00001100;
    /* Replace with your application code */
    while (1) 
    {
		for (count = 0; count < 100; count++){
			// SEL_DISP_1 ==  PORTE.IN[2]
			// SEL_DISP_2 ==  PORTE.IN[3]
			int seconds = 0;
			while (1){
				if(seconds == 100){
					break;
				}
				
				// Prvi display
				PORTE.IN |= SEL_DISP_1;
				PORTC.OUT = segment_codes[(count/10)];
				_delay_ms(5);
				PORTE.IN &= ~SEL_DISP_1;
				//Drugi display
				PORTE.IN |= SEL_DISP_2;
				PORTC.OUT = segment_codes[(count%10)];
				_delay_ms(5);
				PORTE.IN &= ~SEL_DISP_2;
				seconds++;
				
		}
		}
    }
}

