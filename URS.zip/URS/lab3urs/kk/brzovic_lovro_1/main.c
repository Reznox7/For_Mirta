#include <stm32f407xx.h>
#include <stdio.h>
#include "init.h"

//PD12 - H4 ... PD15 - H1

int main(void) {
	volatile uint32_t tmp;
	// Enabling clock for GPIOD
	// |= to preserve other bits, e.g. CCMDATARAMEN
	RCC->AHB1ENR |= (0x1UL << 3);
	// Dummy read. 2 cycles are needed for clock
	// to be turned on after writting into
	// AHB1ENR, AHB2ENR, AHB2ENR, APB1ENR and ABPB2ENR.
	tmp = RCC->AHB1ENR;

	// 0b01XXXX01 XXXXXXXX XXXXXXXX XXXXXXXX
	// Configure pins 15, 12 as output.
	GPIOD->MODER &= ~((0x3UL << 30U) | (0x3UL << 24U)); 
	GPIOD->MODER |= ((0x1UL << 30U) | (0x1UL << 24U));
	
	//GPIOD->ODR &= ~(0x1UL << 15U); // H1 OFF
	//PIOD->ODR |= (0x1UL << 15U); // H1 ON
	GPIOD->ODR |= (0x1UL << 12U); // H4 ON
	while(1); // Stay here forever.
}
