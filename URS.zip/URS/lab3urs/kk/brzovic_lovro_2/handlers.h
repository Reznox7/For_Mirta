#include <stm32f407xx.h>

extern volatile uint32_t msTicks; // Protekle ms

void __attribute__((interrupt)) SysTick_Handler(void);
