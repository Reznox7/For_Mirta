#include <stm32f407xx.h>
#include "handlers.h"

volatile uint32_t msTicks; // Protekle ms

void __attribute__((interrupt)) SysTick_Handler(void) {
	
	msTicks++; // Povecava se za 1 svake milisekunde

}
