#include <stm32f407xx.h>
#include <stdio.h>
#include "init.h"
#include "handlers.h"

//PD12 - H4 ... PD15 - H1
//PB13 Red, PB14 Blue, PB15 Green

void Delay(uint32_t NoOfTicks); // bezvezna deklaracija

void Delay(uint32_t NoOfTicks) {
	
	uint32_t curTicks;
	curTicks = msTicks;
	while ((msTicks - curTicks) < NoOfTicks);
	
}

int main(void) {
	
	volatile uint32_t tmp;
	
	// Enabling clock for GPIOD - LED1-LED4
	RCC->AHB1ENR |= (0x1UL << 3U);
	
	// Enabling clock for GPIOB - RGB LED
	RCC->AHB1ENR |= (0x1UL << 1U);
	
	// Dummy read. 2 cycles are needed for clock
	// to be turned on after writting into
	// AHB1ENR, AHB2ENR, AHB2ENR, APB1ENR and ABPB2ENR.
	tmp = RCC->AHB1ENR;

	// Configure GPIOD pins 12, 13 as output.
	GPIOD->MODER &= ~((0x3UL << 26U) | (0x3UL << 24U));
	GPIOD->MODER |= ((0x1UL << 26U) | (0x1UL << 24U));
	
	// Configure GPIOB pins 13, 14, 15 as output.
	GPIOB->MODER &= ~((0x3UL << 30U) | (0x3UL << 28U) | (0x3UL << 26U));
	GPIOB->MODER |= ((0x1UL << 30U) | (0x1UL << 28U) | (0x1UL << 26U));
	
	// LED on pin 13 OFF, LED on pin 12 ON.
	GPIOD->ODR &= ~(0x1UL << 13U); // H3 OFF
	
	GPIOD->ODR |= (0x1UL << 12U); // H4 ON
	
	while(1){
		
		GPIOB->ODR &= ~((0x1UL << 13U) | (0x1UL << 14U) | (0x1UL << 15U)); // RGB OFF
		
		GPIOB->ODR |= (0x1UL << 13U); // Red ON
		
		Delay(1000);
		
		GPIOB->ODR &= ~(0x1UL << 13U); // Red OFF
		GPIOB->ODR |= (0x1UL << 14U); // Blue ON
		
		Delay(1000);
		
		GPIOB->ODR &= ~(0x1UL << 14U); // Blue OFF
		GPIOB->ODR |= (0x1UL << 15U); // Green ON
		
		Delay(1000);

		GPIOB->ODR &= ~(0x1UL << 15U); // Green OFF
		
		Delay(1000);
	}
	// Stay here forever.
	
}
