#include <stm32f407xx.h>
#include <stdio.h>
#include "init.h"

void init_DefaultClock(void) {
	RCC->CR |= (uint32_t)0x00000001; // HSION=1
	RCC->CFGR = 0x00000000; // Reset CFGR register
	RCC->CR &= (uint32_t)0xFEF6FFFF; // HSEON, CSSON, PLLON =0
	RCC->PLLCFGR = 0x24003010; // Reset PLLCFGR register
	RCC->CR &= (uint32_t)0xFFFBFFFF; // HSEBYP=0
	RCC->CIR = 0x00000000; // Dissable all clock interrupts
}

void init_Clock(void) {
	init_DefaultClock();
	// HSE OSCILLATOR (for Discovery board: Quartz 8 MHz)
	RCC->CR |= RCC_CR_HSEON; // 0x1UL<<16; // HSEON=1;
	while( !(RCC->CR & (0x1UL<<17)) ); // while(HSERDY==0);
	
	// PLL (PLLCLK = 168 MHz)
	//RCC->PLLCFGR = 0x24405408;
	
	//PLLCLK = 50Mhz -> M=8, N=200, P=4
	// ---- QQQQ -S-- --PP -NNN NNNN NNMM MMMM
	// 0010 0100 0100 0001 0011 0010 0000 1000 = 0x24413208
	RCC->PLLCFGR = 0x24413208;
	
	//PLLCLK = 50Mhz -> M=8, N=100, P=2
	// ---- QQQQ -S-- --PP -NNN NNNN NNMM MMMM
	// 0010 0100 0100 0000 0001 1001 0000 1000 = 
	//RCC->PLLCFGR = 0x24401908;
	
	RCC->CR |= 0x1UL<<24; 												// PLLON=1;
	while( !(RCC->CR & (0x1UL<<25)) ); 						// while(PLLRDY==0);
	
	// Clock for HCLK, APB1 presc. and APB2 presc.
	RCC->CFGR |= 0x0UL<<4; // HPRE: divide by 1
	
	// Maximmum prescaller value for APB1 and APB2
	RCC->CFGR |= 0x7UL<<10; // PPRE1: divide by 16
	RCC->CFGR |= 0x7UL<<13; // PPRE2: divide by 16
	
	// Selection of PLLCLK as SYSCLK
	RCC->CFGR |= 0x2UL; // SW=2;
	while( (RCC->CFGR & 0xCUL)>>2 != (RCC->CFGR & 0x3UL) ); // while(SWS!=SW);
	
	// Desired frequencies for APB1 and APB2 clocks
	RCC->CFGR &= ~(0x7UL<<10) | (0x4UL<<10); // PPRE1: div. 2 (AHB1 25MHz)
	RCC->CFGR &= ~(0x7UL<<13) | (0x0UL<<13); // PPRE2: div. 1 (AHB2 50MHz)
}

void init_FlashAccess(void) {
	//uint32_t WS = 1UL;	//broj stanja cekanja = 1 za 50MHz na 3V
	FLASH->ACR = 3//WS
	| (0x1UL<< 8) // FLASH_ACR_PRFTEN
	| (0x1UL<< 9) // FLASH_ACR_ICEN
	| (0x1UL<<10); // FLASH_ACR_DCEN
	while( ((FLASH->ACR)&(0x7))!= 3); // WS wait acception
}
void init_SysTick(void) {
	
	SCB->SHP[11] = 0x2 << 4; // Priority of SysTick
	SCB->AIRCR = (SCB->AIRCR & 0xF8FFUL) | 0x05FA0000UL;
	SysTick->LOAD = 0x1869UL; // RELOAD za 1 manji od cijanog(50Mhz/8/1000-1)
	SysTick->VAL = 0x0UL; // CURRENT=0
	SysTick->CTRL |= 0x3UL; // TICKINT=1, TICKEN=1
}

void init_USART2 (void) {
	volatile uint32_t tmp;
	RCC->AHB1ENR |= (1UL << 3); // Enable GPIOD clock
	RCC->APB1ENR |= (1UL << 17); // Enable USART2 clock
	tmp = RCC->APB1ENR; // Dummy read
	
	GPIOD->AFR[0] |= (7UL << 20); // USART2 TX => PD5
	GPIOD->AFR[0] |= (7UL << 24); // USART2 RX => PD6
	
	GPIOD->MODER &= ~(3UL << 10); // clear bits 10 & 11
	GPIOD->MODER |= 2UL << 10; // MODER5 => alt. func.
	
	// USART2: 9600 baud, 8 bits, 1 stop bit, no parity
	// fAPB1 = 42 MHz PAZI NA OVO, TREBA PODESIT
	
	USART2->CR1 = 0x0UL;
	USART2->CR2 = 0x0UL;
	USART2->CR3 = 0x0UL;
	
	USART2->CR1 |= (1UL << 13); // UE => USART enable
	USART2->CR1 |= (0UL << 12); // M => 8 bits
	USART2->CR1 |= (0UL << 10); // PCE => No pariti
	USART2->CR2 |= (0UL << 12); // STOP => 1 stop bit
	USART2->BRR = 0x1117UL; // BR => 9600 bit/s
	USART2->CR1 |= (1UL << 3); // TE => TX enable
}

void sendchar_USART2(int32_t c) {
	while (!(USART2->SR & 0x0080));
	USART2->DR = (c & 0xFF);
}
