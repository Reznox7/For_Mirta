#include <stm32f407xx.h>
#include "handlers.h"
#include "seven_seg_display.h"

// PC3 Display1, PC0 Display2
// PA0-PA7 7 segments + dot

volatile uint32_t msTicks; // Protekle ms

unsigned int seven_seg_display; //broj prekida

extern volatile uint32_t jedinice;
extern volatile uint32_t desetice;

extern const unsigned char znak[10];


void __attribute__((interrupt)) SysTick_Handler(void) {
	msTicks++; // Povecava se za 1 svake milisekunde
}
void __attribute__((interrupt)) TIM7_IRQHandler(void) {
	
	if((GPIOC->ODR & (0x1UL << 0U)) == 1){ // selektan je disp2
	GPIOC->ODR &= ~(0x1UL << 0U);	// ugasi disp 2
	GPIOA->ODR &= ~(0xFFUL << 0U); // Prazan
	GPIOA->ODR |= (znak[desetice]); // Desetice
	GPIOC->ODR |= ((0x1UL << 3U));	// upali disp 1
	
	}
	else{ // selektan je disp1
	GPIOC->ODR &= ~(0x1UL << 3U);	// ugasi disp 1
	GPIOA->ODR &= ~(0xFFUL << 0U); // Prazan
	GPIOA->ODR |= (znak[jedinice]); // Jedinice
	GPIOC->ODR |= ((0x1UL << 0U));	// upali disp 2
	}
	
	TIM7->SR &= ~(0x01UL);		// ocisti zastavicu
}
