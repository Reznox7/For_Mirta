#include <stm32f407xx.h>

extern volatile uint32_t msTicks; // Protekle ms
extern unsigned int seven_seg_display; //broj prekida

extern volatile uint32_t jedinice;
extern volatile uint32_t desetice;

void __attribute__((interrupt)) SysTick_Handler(void);

void __attribute__((interrupt)) TIM7_IRQHandler(void);
