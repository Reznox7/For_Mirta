#include <stm32f407xx.h>
#include <stdio.h>
#include "init.h"
#include "retarget.h"

void init_DefaultClock(void) {
	RCC->CR |= (uint32_t)0x00000001; // HSION=1
	RCC->CFGR = 0x00000000; // Reset CFGR register
	RCC->CR &= (uint32_t)0xFEF6FFFF; // HSEON, CSSON, PLLON =0
	RCC->PLLCFGR = 0x24003010; // Reset PLLCFGR register
	RCC->CR &= (uint32_t)0xFFFBFFFF; // HSEBYP=0
	RCC->CIR = 0x00000000; // Dissable all clock interrupts
}

void init_Clock(void) {
	init_DefaultClock();
	// HSE OSCILLATOR (for Discovery board: Quartz 8 MHz)
	RCC->CR |= RCC_CR_HSEON; // 0x1UL<<16; // HSEON=1;
	while( !(RCC->CR & (0x1UL<<17U)) ); // while(HSERDY==0);
	// PLL (PLLCLK = 168 MHz)
	//RCC->PLLCFGR = 0x24405408;
	//PLLCLK = 50Mhz -> M=8, N=200, P=4
	// ---- QQQQ -S-- --PP -NNN NNNN NNMM MMMM
	// 0010 0100 0100 0001 0011 0010 0000 1000 = 0x24433210
	//RCC->PLLCFGR = 0x24433210;
	RCC->PLLCFGR = 0x24413208UL;
	//RCC->PLLCFGR = (0x24003010U & (~0x37FFFU)) |  ((0x1UL << 22U) | (0x1UL<<16U) | 0x3208UL) ;
	RCC->CR |= 0x1UL<<24U; // PLLON=1;
	while( !(RCC->CR & (0x1UL<<25U)) ); // while(PLLRDY==0);
	
	// Clock for HCLK, APB1 presc. and APB2 presc.
	RCC->CFGR |= 0x0UL<<4U; // HPRE: divide by 1
	
	// Maximmum prescaller value for APB1 and APB2
	RCC->CFGR |= 0x7UL<<10U; // PPRE1: divide by 16
	RCC->CFGR |= 0x7UL<<13U; // PPRE2: divide by 16
	
	// Selection of PLLCLK as SYSCLK
	RCC->CFGR |= 0x2UL; // SW=2;
	while( (RCC->CFGR & 0xCUL)>>2 != (RCC->CFGR & 0x3UL) ); // while(SWS!=SW);
	
	// Desired frequencies for APB1 and APB2 clocks
	RCC->CFGR &= ~(0x7UL<<10U); // PPRE1: div. 2
	RCC->CFGR |= (0x4UL<<10U);
	RCC->CFGR &= ~(0x7UL<<13U); // PPRE2: div. 1
	RCC->CFGR |= (0x0UL<<13U);
}

void init_FlashAccess(void) {
	uint32_t WS = 1UL;	//broj stanja cekanja 1 za 50MHz na 3V
	FLASH->ACR |= WS
	| (0x1UL<< 8U) // FLASH_ACR_PRFTEN
	| (0x1UL<< 9U) // FLASH_ACR_ICEN
	| (0x1UL<<10U); // FLASH_ACR_DCEN
	while( ((FLASH->ACR)&(0x7UL))!=WS ); // wait acception
}
void init_SysTick(void) {
	
	SCB->SHP[11] = 0x2 << 4; // Priority of SysTick
	SCB->AIRCR = (SCB->AIRCR & 0xF8FFUL) | 0x05FA0000UL;
	SysTick->LOAD = 0x1869UL; // RELOAD za 1 manji od cijanog(50Mhz/8/1000-1)
	SysTick->VAL = 0x0UL; // CURRENT=0
	SysTick->CTRL |= 0x3UL; // TICKINT=1, TICKEN=1
}

void init_USART2 (void) {
	
	volatile uint32_t tmp;
	RCC->AHB1ENR |= (1UL << 3); // Enable GPIOD clock
	RCC->APB1ENR |= (1UL << 17); // Enable USART2 clock
	tmp = RCC->APB1ENR; // Dummy read
	
	/*---Alternativne funkcije GPIO pinova---*/
	GPIOD->AFR[0] |= (7UL << 20); // USART2 TX => PD5
	GPIOD->AFR[0] |= (7UL << 24); // USART2 RX => PD6
	
	GPIOD->MODER &= ~(3UL << 10); // clear bits 10 & 11
	GPIOD->MODER |= 2UL << 10; // MODER5 => alt. func.
	
	// USART2: 9600 baud, 8 bits, 1 stop bit, no parity
	// fAPB1 = 25 MHz
	
	USART2->CR1 = 0x0UL;
	USART2->CR2 = 0x0UL;
	USART2->CR3 = 0x0UL;
	
	USART2->CR1 |= 	(1UL << 13); // UE => USART enable
	USART2->CR1 |= 	(0UL << 12); // M => 8 bits
	USART2->CR1 |= 	(0UL << 10); // PCE => No parity
	USART2->CR2 |= 	(0UL << 12); // STOP => 1 stop bit
	USART2->BRR = 	0x0A2CUL; // BR => 9600 bit/s
	USART2->CR1 |= 	(1UL << 3); // TE => TX enable
}

void init_TIM7 (void){
	
	volatile uint32_t tmp;
	RCC-> APB1ENR |= RCC_APB1ENR_TIM7EN_Msk;  // dovedi clock na apb1
	tmp = RCC->APB1ENR;
	// osvjezavanje 100 ili 50 puta u sekundi?
	TIM7->PSC |= 0x4UL;			//prescaler 5 - 25MHz
	TIM7->ARR |= 50000UL;			// auto reload register - dok dosegne 250000 opet broji od 0
	TIM7->CR1 |= (0x01UL);	// counter enabled
	TIM7->DIER |= (0x01UL);	// interrupt enabled
	// u prekidnoj rutini UIF = 0 TIM7->SR &= ~(0x01UL);
	
	NVIC_SetPriority(TIM7_IRQn,6);
	NVIC_EnableIRQ(TIM7_IRQn); // nez jel ovo treba
	
}


