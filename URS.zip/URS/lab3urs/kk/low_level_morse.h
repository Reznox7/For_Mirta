#include <stm32f407xx.h>
#include <stdio.h>

extern void Delay(uint32_t);


unsigned char * morse_code(unsigned char);
void send_char_morse (char);
void send_string_morse (char *);
void dash(void);
void dot(void);
void razmak_iza_slova(void);
void razmak(int t);
