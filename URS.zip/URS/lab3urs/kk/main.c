#include <stm32f407xx.h>
#include <stdio.h>
#include "init.h"
#include "handlers.h"
#include "retarget.h"
#include "low_level_morse.h"
#include "seven_seg_display.h"

// PD12 - H4 ... PD15 - H1
// PB13 Red, PB14 Blue, PB15 Green
// PE11 Buzzer
// PC3 Display1, PC0 Display2
// PA0-PA7 7 segments + dot
// TIM7 55

void Delay(uint32_t NoOfTicks); // bezvezna deklaracija
void sendchar_USART2(int32_t c);

extern unsigned int seven_seg_display; //broj prekida

volatile uint32_t jedinice  = 0UL;
volatile uint32_t desetice  = 0UL;

void Delay(uint32_t NoOfTicks) {
	uint32_t curTicks;
	curTicks = msTicks;
	while ((msTicks - curTicks) < NoOfTicks);
}

void sendchar_USART2(int32_t c) {
	
	// Je li prethodni character otisao?
	while (!(USART2->SR & 0x0080));
	
	USART2->DR = (c & 0xFF);
}

int main(void) {
	
	volatile uint32_t tmp;
	
	// Enabling clock for GPIOD - LED1-LED4
	RCC->AHB1ENR |= (0x1UL << 3U);
	
	// Enabling clock for GPIOB - RGB LED
	RCC->AHB1ENR |= (0x1UL << 1U);
	
	// Enabling clock for GPIOE - Buzzer
	RCC->AHB1ENR |= (0x1UL << 4U);
	
	// Enabling clock for GPIOC - Display selection
	RCC->AHB1ENR |= (0x1UL << 2U);
	
	// Enabling clock for GPIOA - 7 segment display
	RCC->AHB1ENR |= (0x1UL << 0U);
	
	// Dummy read. 2 cycles are needed for clock
	// to be turned on after writting into
	// AHB1ENR, AHB2ENR, AHB2ENR, APB1ENR and ABPB2ENR.
	tmp = RCC->AHB1ENR;

	// Configure GPIOD pins 12, 13 as output.
	GPIOD->MODER &= ~((0x3UL << 26U) | (0x3UL << 24U));
	GPIOD->MODER |= ((0x1UL << 26U) | (0x1UL << 24U));
	
	// Configure GPIOB pins 13, 14, 15 as output.
	GPIOB->MODER &= ~((0x3UL << 30U) | (0x3UL << 28U) | (0x3UL << 26U));
	GPIOB->MODER |= ((0x1UL << 30U) | (0x1UL << 28U) | (0x1UL << 26U));
	
	// Configure GPIOE pin 11 as output.
	GPIOE->MODER &= ~((0x3UL << 22U));
	GPIOE->MODER |= ((0x1UL << 22U));
	
	// Configure GPIOC pins 0, 3 as output.
	GPIOC->MODER &= ~((0x3UL << 0U) | (0x3UL << 6U));
	GPIOC->MODER |= ((0x1UL << 0U) | (0x1UL << 6U));
	
	// Configure GPIOA pins 0-7 as output.
	//GPIOA->MODER &= ~(0xFFFFUL << 0U);
	//GPIOA->MODER |= (0x5555UL << 0U);
	
	GPIOA->MODER &= ~((0x3UL << 0U) | (0x3UL << 2U) | (0x3UL << 4U)| (0x3UL << 6U)| (0x3UL << 8U)| (0x3UL << 10U)| (0x3UL << 12U)| (0x3UL << 14U));
	GPIOA->MODER |= ((0x1UL << 0U) | (0x1UL << 2U) | (0x1UL << 4U)| (0x1UL << 6U)| (0x1UL << 8U)| (0x1UL << 10U )| (0x1UL << 12U)| (0x1UL << 14U));
		
	
	/*---Single LED---*/
	// LED on pin 13 OFF, LED on pin 12 ON.
	GPIOD->ODR &= ~(0x1UL << 13U); // H3 OFF
	
	GPIOD->ODR |= (0x1UL << 12U); // H4 ON
	
	/*---RGB LED---*/
	
	GPIOB->ODR &= ~((0x1UL << 13U) | (0x1UL << 14U) | (0x1UL << 15U)); // RGB OFF
		
	GPIOB->ODR |= (0x1UL << 13U); // Red ON
	
	Delay(1000);
	
	GPIOB->ODR &= ~(0x1UL << 13U); // Red OFF
	GPIOB->ODR |= (0x1UL << 14U); // Blue ON
	
	Delay(1000);
	
	GPIOB->ODR &= ~(0x1UL << 14U); // Blue OFF
	GPIOB->ODR |= (0x1UL << 15U); // Green ON
	
	Delay(1000);

	GPIOB->ODR &= ~(0x1UL << 15U); // Green OFF
	
	/*---USART ispis u terminal---*/
	printf ("Redefinicija sistemskih poziva uspjesno napravljena !\n\r"); // mljac
	
	/*---Morseov kod beep beep beep---*/

	
	//FILE *fMorse=fopen ("Morse","w");
	//fprintf (fMorse,"SOS - SOS - PURS");
	//fclose (fMorse);
	
	
while(1){
	
	// promijeni stanje H3
	if((GPIOD->ODR & (0x1UL << 13U)) == 0){	
		GPIOD->ODR |= (0x1UL << 13U); 	// H3 ON
	}
	else{
		GPIOD->ODR &= ~(0x1UL << 13U); 	// H3 OFF
	}
	
	jedinice = seven_seg_display % 10;
	desetice = (seven_seg_display / 10) % 10;	
	
	printf ("Broj prolaza = %u \n\r", seven_seg_display);
	//tu ocekujem da ce se dogadat tih 100 prekida u sekundi
	/*
	GPIOA->ODR &= ~(0xFFUL << 0U); // Prazan
	GPIOA->ODR |= (znak[desetice]); // Desetice
	GPIOC->BSRR = GPIO_BSRR_BR0 | GPIO_BSRR_BS3;
	Delay(50);
	GPIOA->ODR &= ~(0xFFUL << 0U); // Prazan
	GPIOA->ODR |= (znak[jedinice]); // Jedinice
	GPIOC->BSRR = GPIO_BSRR_BR3 | GPIO_BSRR_BS0;
	Delay(40);
	*/
	Delay(1000);
	
	seven_seg_display++; // Broji prekide
	}
	
}
