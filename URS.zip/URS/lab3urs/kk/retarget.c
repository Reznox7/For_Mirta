#include <stdio.h> // decl. of FILE, __stdin, __stdout
#include <rt_sys.h> // declaration of _sys_exit, etc.
#include <rt_misc.h> // razne funkcije za redeficiciju
#include <string.h> // strncmp i sl.
#include "retarget.h"
#include "low_level_morse.h"

#define FH_STDIN 	0x8001
#define FH_STDOUT 0x8002
#define FH_STDERR 0x8003
#define FH_MORSE	0x1234

extern void sendchar_USART2(int);

__asm(".global __use_no_semihosting");

//otvara datoteku ili jedinicu
FILEHANDLE _sys_open(const char * name, int openmode){
	
	(void)openmode;
	
	if (!strncmp(name, ":STDIN",6)) {
		return(FH_STDIN);
	} 
	else if (!strncmp(name, ":STDOUT",7)) {
		return(FH_STDOUT);
	} 
	else if (!strncmp(name, ":STDERR",7)) {
		return(FH_STDERR);
	} 
	else if (!strncmp(name, "Morse",5)) {		// 5 slova ocekujemo
		return(FH_MORSE);
	} 
	else {
		return (-1); // ostalo nije implementirano
	}
	
}

//provjerava je li dana datoteka "spojena" s interaktivnom jedinicom (npr. konzolom)
int _sys_istty(FILEHANDLE fh) {
	if (fh==FH_STDIN) {
		return (1); // tty
	} 
	else if (fh==FH_STDOUT) {
		return (1); // tty
	} 
	else if (fh==FH_STDERR) {
		return (1); // tty
	} 
	else if (fh==FH_MORSE) {	// ayyyyy
		return (1); // tty
	} 
	else {
		return (-1); // ostalo nije implementirano
	}
}


//upisuje podatke u datoteku ili jedinicu
int _sys_write(FILEHANDLE fh, const unsigned char * buf, unsigned len, int mode) {
	
	(void)mode;
	
	if (fh==FH_STDOUT) { // konzola
		while(len != 0) {
		sendchar_USART2(*buf);
		buf++;
		len--;
		}
		return (0);
	} 
	else if (fh==FH_MORSE) {
		while(len != 0) {
		send_char_morse(*buf); // ne znam jel tu mora ic send_char_morse (char c)
		buf++;
		len--;
		} 
		return (0); 
	}	
	else {
		return (-1); // ostalo nije implementirano
	}
	
}

//signalizira (ispisuje) gre�ku ("posljednja �ansa")
void _ttywrch(int ch){
	
	sendchar_USART2(ch);
	
}

//kaze da proucim
__attribute__((noreturn)) void _sys_exit(int return_code){
	
	(void)return_code;
	
	while(1);
	
}

int _sys_close (FILEHANDLE fh){
	switch (fh) {
    case FH_STDIN:
      return (0);
    case FH_STDOUT:
      return (0);
    case FH_STDERR:
      return (0);
		case FH_MORSE:
			return (1);
		default:
			return (-1);
	}
}


/*
extern void sendchar_USART2(int);

// to warn in all semihosting calls are not redefined
__asm(".global __use_no_semihosting");

FILE __stdout;

int fputc(int c, FILE *f) {
	
	(void)f; // suppress warning for unused parameter
	sendchar_USART2(c);
	return(c);
	
}

int ferror(FILE *f) {
	
	(void)	f;
	return 	EOF;
	
}
__attribute__((noreturn)) void _sys_exit(int return_code){
	
	(void)return_code;
	while(1);
	
}
*/
