#include "seven_seg_display.h"

#define Seg_A (1<<3)
#define Seg_B (1<<2)
#define Seg_C (1<<4)
#define Seg_D (1<<7)
#define Seg_E (1<<5)
#define Seg_F (1<<0)
#define Seg_G (1<<1)
#define Seg_DP (1<<6)

// A => PA3
// B => PA2 A
// C => PA4 F B
// D => PA7 G
// E => PA5 E C
// F => PA0 D
// G => PA1
// DP => PA6

const unsigned char znak[10]={
	Seg_A | Seg_B | Seg_C | Seg_D | Seg_E | Seg_F , 				// 0
	Seg_B | Seg_C , 																				// 1
	Seg_A | Seg_B | Seg_D | Seg_E | Seg_G, 									// 2
	Seg_A | Seg_B | Seg_C | Seg_D | Seg_G, 									// 3
	Seg_B | Seg_C | Seg_F | Seg_G, 													// 4
	Seg_A | Seg_C | Seg_D | Seg_F | Seg_G, 									// 5
	Seg_A | Seg_C | Seg_D | Seg_E | Seg_F | Seg_G, 					// 6
	Seg_A | Seg_B | Seg_C , 																// 7
	Seg_A | Seg_B | Seg_C | Seg_D | Seg_E | Seg_F | Seg_G,	// 8
	Seg_A | Seg_B | Seg_C | Seg_D | Seg_F | Seg_G, 					// 9
};
