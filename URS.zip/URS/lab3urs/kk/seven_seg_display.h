#include <stm32f407xx.h>

extern const unsigned char znak[10];
